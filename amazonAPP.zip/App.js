import AppNavigator from './src/app/navigation';

const App = () => {
    return <AppNavigator />;
};

export default App;