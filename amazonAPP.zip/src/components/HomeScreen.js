import React, { useEffect, useState } from 'react';
import { View, Text, Image } from 'react-native';
import { StyleSheet } from 'react-native';

const HomeScreen = () => {
    
    const url = 'https://real-time-amazon-data.p.rapidapi.com/product-details?asin=B07ZPKBL9V&country=US';
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '2137d8cbcdmsh106d594378e47bap1dd37djsn6fef5c75e037',
            'X-RapidAPI-Host': 'real-time-amazon-data.p.rapidapi.com'
        }
    };

    const [data, setData] = useState([]);
    console.log(data);

    useEffect(() => {
        fetch(url, options)
            .then((response) => response.json())
            .then((results) => setData(results.data))
            .catch((error) => console.error(error));
        
    }, []);

    return (
        <View style={styles.container}>
            <View style={styles.card}>
                <Image style={styles.image} source={{ uri: data.product_photo }} />
                <Text>{data.product_title}</Text>
            </View>
        </View>
    );
};

export default HomeScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'row', 
        justifyContent: 'center',
        alignItems: 'center'
    },
    image: {
        width: 100,
        height: 100,
        margin: 5
    },
    card: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        padding: 10,
        margin: 10,
        backgroundColor: '#ffff',
        borderRadius: 10,
        shadowColor: '#000',
    }
});
